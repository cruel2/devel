
/*

includes part from:

http://gasstationwithoutpumps.wordpress.com/2011/10/08/making-wav-files-from-c-programs/

*/

/* test_make_wav.c
 * Fri Jun 18 17:13:19 PDT 2010 Kevin Karplus
 * Test program for the write_wav function in make_wav.c
 */
 
#include <math.h>
#include "make_wav.h"
 
#define S_RATE  (44100)
#define BUF_SIZE (S_RATE*2) /* 2 second buffer */
 
int buffer[BUF_SIZE];
 
int main(int argc, char ** argv)
{
    int i;
    float t;
    float amplitude = 16000;
    float freq_Hz = 440;
    float phase1 = 0.0;
    float phase2 = 0.0;
    float phase3 = 0.0;
 
    // frequency: radians per sampling rate
    float freq1 = freq_Hz*2*M_PI/S_RATE;
    float freq2 = freq1 * 1.5;
    float freq3 = freq1 * 2.0;
 
    /* fill buffer with a sine wave */
    for (i=0; i<BUF_SIZE; i++)
    {
        if (i < BUF_SIZE/3)
        {
            phase1 += freq1;
            phase2 += freq2;
            phase3 += freq3;
            
            buffer[i] = (int)(amplitude * 
                (sin(phase1) * 1.0 + 
                 sin(phase2) * 0.7 + 
                 sin(phase3) * 0.4 ));
        }
        else if (i < 2*BUF_SIZE/3)
        {
            phase1 += freq1;
            phase2 += freq2;
            phase3 += freq3;
            
            buffer[i] = (int)(amplitude * 
                (sin(phase1) * 0.0 + 
                 sin(phase2) * 0.7 + 
                 sin(phase3) * 0.4 ));
        }
        else buffer[i] = 0;
    }
 
    write_wav("test.wav", BUF_SIZE, buffer, S_RATE);
 
    return 0;
}

